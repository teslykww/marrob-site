import Header from './sections/Header';
import Hero from './sections/Hero';
import Problem from './sections/Problem';
import Solution from './sections/Solution';
import BeforeAfter from './sections/BeforeAfter';
import Catalog from './sections/Catalog';
import Gallery from './sections/Gallery';
import Reviews from './sections/Reviews';
import Specs from './sections/Specs';
import Warranty from './sections/Warranty';
import Scenarios from './sections/Scenarios';
import FAQ from './sections/FAQ';
import Contact from './sections/Contact';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-bg">
      <Header />
      <main>
        <Hero />
        <Problem />
        <Solution />
        <BeforeAfter />
        <Catalog />
        <Gallery />
        <Reviews />
        <Specs />
        <Warranty />
        <Scenarios />
        <FAQ />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
