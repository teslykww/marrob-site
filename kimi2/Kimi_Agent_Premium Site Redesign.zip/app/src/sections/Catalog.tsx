import React, { useState } from 'react';
import { ChevronRightIcon } from '../components/icons/BuildingIcons';

const Catalog: React.FC = () => {
  const [activeCollection, setActiveCollection] = useState(0);

  const collections = [
    {
      name: 'Клинкерный кирпич',
      description: 'Классический клинкер с характерной текстурой и насыщенными цветами',
      image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',
      colors: [
        { name: 'Красный', hex: '#8B3A3A' },
        { name: 'Коричневый', hex: '#654321' },
        { name: 'Песочный', hex: '#C2B280' },
        { name: 'Графит', hex: '#36454F' },
      ],
    },
    {
      name: 'Версальский кирпич',
      description: 'Элегантный стиль французского дворца с изысканными оттенками',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
      colors: [
        { name: 'Кремовый', hex: '#F5F5DC' },
        { name: 'Бежевый', hex: '#D2B48C' },
        { name: 'Серый', hex: '#808080' },
        { name: 'Антрацит', hex: '#293133' },
      ],
    },
    {
      name: 'Византийский кирпич',
      description: 'Восточная роскошь и богатство деталей в каждой панели',
      image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&q=80',
      colors: [
        { name: 'Терракота', hex: '#E2725B' },
        { name: 'Охра', hex: '#CC7722' },
        { name: 'Песок', hex: '#C2B280' },
        { name: 'Тёмный', hex: '#3D3D3D' },
      ],
    },
    {
      name: 'Скандинавский кирпич',
      description: 'Северная простота и функциональность в минималистичном дизайне',
      image: 'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&q=80',
      colors: [
        { name: 'Белый', hex: '#F5F5F5' },
        { name: 'Светло-серый', hex: '#D3D3D3' },
        { name: 'Серый', hex: '#A9A9A9' },
        { name: 'Тёмно-серый', hex: '#696969' },
      ],
    },
    {
      name: 'Туринский кирпич',
      description: 'Итальянская классика и изысканность для элитных проектов',
      image: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&q=80',
      colors: [
        { name: 'Карамель', hex: '#C68E17' },
        { name: 'Капучино', hex: '#B8906A' },
        { name: 'Мокко', hex: '#6F4E37' },
        { name: 'Эспрессо', hex: '#3B2F2F' },
      ],
    },
    {
      name: 'Шумерский кирпич',
      description: 'Древние мотивы в современном исполнении для уникальных фасадов',
      image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',
      colors: [
        { name: 'Песчаник', hex: '#D4C4A8' },
        { name: 'Глина', hex: '#B66A50' },
        { name: 'Сланец', hex: '#708090' },
        { name: 'Базальт', hex: '#2F2F2F' },
      ],
    },
  ];

  const currentCollection = collections[activeCollection];

  return (
    <section id="catalog" className="section-premium bg-white relative overflow-hidden">
      {/* Decorative blob */}
      <div className="absolute top-1/2 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl translate-x-1/2" />
      
      <div className="container-premium relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="badge-premium mb-4">Каталог</span>
          <h2 className="font-display font-semibold text-3xl md:text-4xl text-text mb-4">
            Коллекции термопанелей <span className="text-primary">MARROB</span>
          </h2>
          <p className="text-text-muted text-lg">
            Более 100 вариантов фактур и оттенков под натуральный камень
          </p>
        </div>

        {/* Collection Tabs */}
        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {collections.map((collection, index) => (
            <button
              key={index}
              onClick={() => setActiveCollection(index)}
              className={`px-5 py-3 rounded-full text-sm font-medium transition-all ${
                activeCollection === index
                  ? 'bg-primary text-white shadow-premium-md'
                  : 'bg-sand-light text-text-muted hover:bg-primary-light hover:text-primary'
              }`}
            >
              {collection.name}
            </button>
          ))}
        </div>

        {/* Collection Display */}
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          {/* Image */}
          <div className="relative rounded-2xl overflow-hidden shadow-premium-lg group">
            <img
              src={currentCollection.image}
              alt={currentCollection.name}
              className="w-full h-[400px] object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 text-white">
              <h3 className="font-display font-semibold text-2xl mb-2">{currentCollection.name}</h3>
              <p className="text-white/80 text-sm">{currentCollection.description}</p>
            </div>
          </div>

          {/* Details */}
          <div>
            <h3 className="font-display font-semibold text-2xl text-text mb-3">
              {currentCollection.name}
            </h3>
            <p className="text-text-muted mb-8">
              {currentCollection.description}
            </p>

            {/* Colors */}
            <div className="mb-8">
              <p className="text-xs uppercase tracking-wider text-text-light mb-4">
                Доступные цвета
              </p>
              <div className="grid grid-cols-4 gap-4">
                {currentCollection.colors.map((color, index) => (
                  <div key={index} className="text-center">
                    <div
                      className="w-full aspect-square rounded-xl border-2 border-border mb-2 shadow-premium hover:shadow-premium-md transition-shadow"
                      style={{ backgroundColor: color.hex }}
                    />
                    <span className="text-xs text-text-muted">{color.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <a
              href="#contact"
              className="inline-flex items-center gap-2 btn-premium btn-premium--primary"
            >
              Узнать цену этой коллекции
              <ChevronRightIcon size={18} />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Catalog;
