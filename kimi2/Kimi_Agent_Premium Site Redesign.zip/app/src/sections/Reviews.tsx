import React from 'react';
import { StarIcon } from '../components/icons/BuildingIcons';

const Reviews: React.FC = () => {
  const reviews = [
    {
      image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&q=80',
      text: 'Долго выбирали между штукатуркой и панелями. Выбрали MARROB и не пожалели. Дом 180 м² обшили за 2 недели. Зимой стало заметно теплее, а выглядит как настоящий кирпич.',
      author: 'Михаил В.',
      location: 'Московская область, Истра',
      rating: 5,
    },
    {
      image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&q=80',
      text: 'Отличная команда! Приехали, сделали замеры, через 3 недели привезли панели. Монтажники работали аккуратно, мусор убрали. Фасад радует каждый день.',
      author: 'Елена С.',
      location: 'КП «Новорижский»',
      rating: 5,
    },
    {
      image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=600&q=80',
      text: 'Искал надёжное решение для утепления старого дома из пеноблока. Термопанели решили сразу две задачи: дом стал тёплым и выглядит как новая усадьба. Рекомендую!',
      author: 'Дмитрий К.',
      location: 'Дмитровский район',
      rating: 5,
    },
  ];

  return (
    <section className="section-premium bg-white relative overflow-hidden">
      {/* Decorative blob */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      
      <div className="container-premium relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="badge-premium mb-4">Отзывы</span>
          <h2 className="font-display font-semibold text-3xl md:text-4xl text-text mb-4">
            Что говорят наши клиенты
          </h2>
          <p className="text-text-muted text-lg">
            Реальные истории владельцев домов, которые выбрали MARROB
          </p>
        </div>

        {/* Reviews Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {reviews.map((review, index) => (
            <div
              key={index}
              className="bg-sand-light rounded-2xl overflow-hidden shadow-premium hover:shadow-premium-md transition-all duration-300"
            >
              {/* Image */}
              <div className="relative aspect-video overflow-hidden">
                <img
                  src={review.image}
                  alt={`Дом клиента ${review.author}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                <div className="absolute bottom-4 left-4 flex items-center gap-1">
                  {[...Array(review.rating)].map((_, i) => (
                    <StarIcon key={i} size={16} className="text-amber-400 fill-amber-400" />
                  ))}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <p className="text-text-muted text-sm leading-relaxed mb-6 italic">
                  «{review.text}»
                </p>
                <div className="pt-4 border-t border-border">
                  <p className="font-display font-semibold text-text">{review.author}</p>
                  <p className="text-text-light text-xs">{review.location}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
