import React, { useState } from 'react';
import { 
  LayersIcon, 
  ShieldIcon, 
  ToolIcon, 
  GridIcon,
  CheckCircleIcon,
  ThermometerIcon,
  SunIcon,
  SnowflakeIcon,
  FlameIcon,
  WindIcon,
  HomeIcon
} from '../components/icons/BuildingIcons';

const Solution: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'structure' | 'mounting'>('structure');

  const layers = [
    {
      icon: <ShieldIcon size={20} />,
      title: 'Декоративная облицовка',
      detail: 'Более 100 вариантов',
      description: 'Фактура под натуральный камень с защитным покрытием от УФ-излучения',
      color: 'from-amber-500 to-amber-600',
    },
    {
      icon: <GridIcon size={20} />,
      title: 'Замковая геометрия',
      detail: 'Точность: ±0,5 мм',
      description: 'Плотная стыковка панелей без щелей и мостиков холода',
      color: 'from-blue-500 to-blue-600',
    },
    {
      icon: <LayersIcon size={20} />,
      title: 'Плотный утеплитель',
      detail: 'Толщина: 50–100 мм',
      description: 'ППС высокой плотности (15–25 кг/м³) обеспечивает отличную теплоизоляцию',
      color: 'from-green-500 to-green-600',
    },
    {
      icon: <ToolIcon size={20} />,
      title: 'Механическое крепление',
      detail: 'Скрытый монтаж',
      description: 'Надёжная фиксация к основанию с распределением нагрузки',
      color: 'from-slate-500 to-slate-600',
    },
  ];

  const advantages = [
    { icon: <ShieldIcon size={22} />, title: 'Стойкость к внешним воздействиям', description: 'Не повреждаются ветром, осадками, не впитывают влагу' },
    { icon: <FlameIcon size={22} />, title: 'Огнестойкость и безопасность', description: 'Класс горючести Г2, соответствует нормам пожарной безопасности' },
    { icon: <HomeIcon size={22} />, title: 'Монтаж на существующие фасады', description: 'Подходит для нового строительства и реконструкции' },
    { icon: <ThermometerIcon size={22} />, title: 'Энергоэффективность', description: 'Снижают теплопотери до 60%, экономия на отоплении' },
    { icon: <SunIcon size={22} />, title: 'Стабильный микроклимат', description: 'Зимой тепло, летом прохладно внутри дома' },
    { icon: <SnowflakeIcon size={22} />, title: 'Морозостойкость F100', description: 'Выдерживает более 100 циклов замораживания' },
    { icon: <WindIcon size={22} />, title: 'Влагостойкость', description: 'Водопоглощение не более 2% по объёму' },
    { icon: <CheckCircleIcon size={22} />, title: 'Срок службы 40+ лет', description: 'Гарантированная долговечность конструкции' },
  ];

  return (
    <section className="section-premium bg-white relative overflow-hidden">
      {/* Decorative blob */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
      
      <div className="container-premium relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="badge-premium mb-4">Решение</span>
          <h2 className="font-display font-semibold text-3xl md:text-4xl text-text mb-4">
            Термопанель — <span className="text-primary">утепление и фасад</span> в одной системе
          </h2>
          <p className="text-text-muted text-lg">
            Готовая фасадная система 2 в 1: современное решение для утепления и отделки дома
          </p>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-start mb-16">
          {/* Left: Panel Visualization */}
          <div>
            {/* Tabs */}
            <div className="flex gap-2 p-1.5 bg-sand-light rounded-xl mb-6">
              <button
                onClick={() => setActiveTab('structure')}
                className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'structure'
                    ? 'bg-white text-primary shadow-sm'
                    : 'text-text-muted hover:text-text'
                }`}
              >
                Структура панели
              </button>
              <button
                onClick={() => setActiveTab('mounting')}
                className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'mounting'
                    ? 'bg-white text-primary shadow-sm'
                    : 'text-text-muted hover:text-text'
                }`}
              >
                Схема монтажа
              </button>
            </div>

            {/* Panel Visualization */}
            {activeTab === 'structure' ? (
              <div className="space-y-3">
                {layers.map((layer, index) => (
                  <div
                    key={index}
                    className="bg-white rounded-xl border border-border p-4 hover:shadow-premium-md transition-all duration-300 hover:-translate-y-0.5"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${layer.color} flex items-center justify-center text-white flex-shrink-0`}>
                        {layer.icon}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-1">
                          <h4 className="font-display font-semibold text-text">{layer.title}</h4>
                          <span className="text-xs px-2 py-0.5 bg-primary-light text-primary rounded-full">
                            {layer.detail}
                          </span>
                        </div>
                        <p className="text-text-muted text-sm">{layer.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-sand-light rounded-2xl p-8 text-center">
                <div className="w-24 h-24 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <ToolIcon size={40} className="text-white" />
                </div>
                <h4 className="font-display font-semibold text-xl text-text mb-2">
                  Механическое крепление к стене
                </h4>
                <p className="text-text-muted mb-6">
                  Без мокрых процессов и клея — монтаж возможен при отрицательных температурах
                </p>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white rounded-xl p-4">
                    <div className="font-display font-bold text-2xl text-primary mb-1">5-7</div>
                    <div className="text-xs text-text-light">дней монтаж</div>
                  </div>
                  <div className="bg-white rounded-xl p-4">
                    <div className="font-display font-bold text-2xl text-primary mb-1">2</div>
                    <div className="text-xs text-text-light">человека бригада</div>
                  </div>
                  <div className="bg-white rounded-xl p-4">
                    <div className="font-display font-bold text-2xl text-primary mb-1">−15°</div>
                    <div className="text-xs text-text-light">мин. температура</div>
                  </div>
                </div>
              </div>
            )}

            {/* Summary */}
            <div className="mt-6 bg-primary-light rounded-xl p-5 flex items-start gap-4">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center text-white flex-shrink-0">
                <CheckCircleIcon size={20} />
              </div>
              <div>
                <h4 className="font-display font-semibold text-text mb-1">Монтаж в один этап</h4>
                <p className="text-text-muted text-sm">
                  Термопанель объединяет утеплитель и декоративную облицовку в единой конструкции. 
                  Монтаж выполняется без мокрых процессов и дополнительной отделки.
                </p>
              </div>
            </div>
          </div>

          {/* Right: Advantages Grid */}
          <div>
            <h3 className="font-display font-semibold text-xl text-text mb-6">
              Основные преимущества
            </h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {advantages.map((advantage, index) => (
                <div
                  key={index}
                  className="bg-sand-light rounded-xl p-5 hover:bg-white hover:shadow-premium transition-all duration-300"
                >
                  <div className="w-10 h-10 bg-primary-light rounded-lg flex items-center justify-center text-primary mb-3">
                    {advantage.icon}
                  </div>
                  <h4 className="font-display font-medium text-text mb-1 text-sm">
                    {advantage.title}
                  </h4>
                  <p className="text-text-light text-xs leading-relaxed">
                    {advantage.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="bg-gradient-to-r from-primary to-green-dark rounded-2xl p-8 md:p-10 text-center text-white">
          <h3 className="font-display font-semibold text-2xl md:text-3xl mb-3">
            Дом получает одновременно утепление и капитальный каменный фасад
          </h3>
          <p className="text-white/80 mb-6 max-w-2xl mx-auto">
            Замковая геометрия обеспечивает плотную стыковку панелей без щелей и мостиков холода
          </p>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 bg-white text-primary px-8 py-4 rounded-xl font-display font-semibold hover:bg-white/90 transition-colors"
          >
            Получить консультацию
          </a>
        </div>
      </div>
    </section>
  );
};

export default Solution;
