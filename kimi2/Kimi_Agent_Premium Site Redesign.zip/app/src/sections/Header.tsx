import React, { useState, useEffect } from 'react';
import { MenuIcon, XIcon, PhoneIcon } from '../components/icons/BuildingIcons';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '#about', label: 'О термопанелях' },
    { href: '#catalog', label: 'Коллекции' },
    { href: '#gallery', label: 'Объекты' },
    { href: '#specs', label: 'Параметры' },
    { href: '#contact', label: 'Контакты' },
  ];

  return (
    <>
      {/* Top Bar */}
      <div className="hidden lg:block bg-bg-dark text-text-light text-xs py-2">
        <div className="container-premium flex justify-between items-center">
          <div className="flex gap-6">
            <span>МО, Одинцово, ул. Баковская 2А</span>
            <span className="text-primary">Собственное производство</span>
            <span>Срок службы панелей 30 лет</span>
          </div>
          <a href="mailto:info@marrob.ru" className="hover:text-primary transition-colors">
            info@marrob.ru
          </a>
        </div>
      </div>

      {/* Main Header */}
      <header
        className={`fixed top-0 lg:top-[36px] left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-white/95 backdrop-blur-md shadow-premium'
            : 'bg-transparent'
        }`}
      >
        <div className="container-premium">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <a href="/" className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <span className="text-white font-display font-bold text-lg">M</span>
              </div>
              <div className="hidden sm:block">
                <span className="font-display font-semibold text-lg text-text">MARROB</span>
                <p className="text-xs text-text-light -mt-1">Фасадные термопанели</p>
              </div>
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-sm font-medium text-text-muted hover:text-primary transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </nav>

            {/* CTA */}
            <div className="hidden lg:flex items-center gap-4">
              <a
                href="tel:+79166662335"
                className="flex items-center gap-2 text-sm font-medium text-text hover:text-primary transition-colors"
              >
                <PhoneIcon size={18} />
                +7 (916) 666-23-35
              </a>
              <a
                href="#contact"
                className="btn-premium btn-premium--primary text-sm py-3 px-6"
              >
                Заказать звонок
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="lg:hidden p-2 text-text"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <XIcon size={24} /> : <MenuIcon size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-300 ${
          isMobileMenuOpen ? 'visible' : 'invisible'
        }`}
      >
        <div
          className={`absolute inset-0 bg-black/50 transition-opacity ${
            isMobileMenuOpen ? 'opacity-100' : 'opacity-0'
          }`}
          onClick={() => setIsMobileMenuOpen(false)}
        />
        <div
          className={`absolute top-20 right-0 w-full max-w-sm bg-white shadow-premium-lg rounded-l-2xl p-6 transition-transform ${
            isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
        >
          <nav className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-lg font-medium text-text py-2 border-b border-border"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="mt-6 pt-6 border-t border-border">
            <a
              href="tel:+79166662335"
              className="flex items-center gap-2 text-lg font-medium text-text mb-4"
            >
              <PhoneIcon size={20} />
              +7 (916) 666-23-35
            </a>
            <a
              href="#contact"
              className="btn-premium btn-premium--primary w-full"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Заказать звонок
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default Header;
