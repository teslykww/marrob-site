import React from 'react';
import { CheckCircleIcon, ThermometerIcon, LayersIcon, GridIcon } from '../components/icons/BuildingIcons';

const Hero: React.FC = () => {
  const benefits = [
    { icon: <LayersIcon size={20} />, text: 'Утепление и отделка в одной системе' },
    { icon: <GridIcon size={20} />, text: 'Более 100 фактур и оттенков' },
    { icon: <ThermometerIcon size={20} />, text: 'Замковая геометрия без мостиков холода' },
  ];

  return (
    <section className="relative min-h-screen flex items-center pt-32 pb-20 overflow-hidden">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1920&q=80"
          alt="Дом с фасадными термопанелями"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/95 to-white/70" />
        <div className="absolute inset-0 bg-gradient-to-t from-white/50 to-transparent" />
      </div>

      {/* Decorative elements */}
      <div className="absolute top-1/4 right-10 w-64 h-64 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-accent/10 rounded-full blur-3xl" />

      <div className="container-premium relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="max-w-xl">
            {/* Badges */}
            <div className="flex flex-wrap gap-3 mb-6">
              <span className="badge-premium">Собственное производство</span>
              <span className="badge-premium bg-accent-light text-accent">30 лет гарантии</span>
            </div>

            {/* Title */}
            <h1 className="font-display font-semibold text-4xl md:text-5xl lg:text-[3.25rem] leading-tight text-text mb-6">
              Фасадные термопанели
              <span className="block text-primary mt-2">с облицовкой под натуральный камень</span>
            </h1>

            {/* Subtitle */}
            <p className="text-lg md:text-xl text-text-muted mb-4">
              Экономия до <span className="font-semibold text-accent">50–60%</span> на теплопотерях. Напрямую от производителя.
            </p>
            <p className="text-text-light mb-8">
              Возможна покупка панелей отдельно или монтаж под ключ.
            </p>

            {/* Benefits */}
            <ul className="space-y-3 mb-8">
              {benefits.map((benefit, index) => (
                <li key={index} className="flex items-center gap-3 text-text-muted">
                  <span className="flex-shrink-0 w-8 h-8 bg-primary-light rounded-lg flex items-center justify-center text-primary">
                    {benefit.icon}
                  </span>
                  {benefit.text}
                </li>
              ))}
            </ul>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#contact"
                className="btn-premium btn-premium--primary text-center"
              >
                Рассчитать фасад
              </a>
              <a
                href="#catalog"
                className="btn-premium btn-premium--outline text-center"
              >
                Купить панели
              </a>
            </div>
          </div>

          {/* Stats Card */}
          <div className="hidden lg:block relative">
            <div className="absolute -top-10 right-0 bg-white rounded-2xl shadow-premium-lg p-6 animate-fade-in">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-primary-light rounded-xl flex items-center justify-center text-primary">
                  <CheckCircleIcon size={28} />
                </div>
                <div>
                  <div className="font-display font-bold text-3xl text-text">6 500+</div>
                  <div className="text-text-light text-sm">Реализованных объектов</div>
                </div>
              </div>
            </div>

            {/* Secondary stats */}
            <div className="absolute bottom-10 right-10 bg-white/95 backdrop-blur rounded-xl shadow-premium p-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-accent-light rounded-lg flex items-center justify-center text-accent">
                  <ThermometerIcon size={20} />
                </div>
                <div>
                  <div className="font-display font-semibold text-text">до 60%</div>
                  <div className="text-text-light text-xs">экономия тепла</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-text-light">
        <span className="text-xs uppercase tracking-widest">Scroll</span>
        <div className="w-6 h-10 border-2 border-primary/30 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-1.5 bg-primary rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
