import React, { useState } from 'react';
import { 
  PhoneIcon, 
  MailIcon, 
  MapPinIcon,
  CheckCircleIcon 
} from '../components/icons/BuildingIcons';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const contacts = [
    {
      icon: <PhoneIcon size={24} />,
      title: 'Телефон',
      value: '+7 (916) 666-23-35',
      href: 'tel:+79166662335',
    },
    {
      icon: <MailIcon size={24} />,
      title: 'Email',
      value: 'info@marrob.ru',
      href: 'mailto:info@marrob.ru',
    },
    {
      icon: <MapPinIcon size={24} />,
      title: 'Адрес',
      value: 'МО, Одинцово, ул. Баковская 2А',
      href: 'https://yandex.ru/maps/10716/odintsovo/house/bakovskaya_ulitsa_2a/Z04Yfg5jT0QBQFtvfX5wdH1hZA==/?ll=37.270970%2C55.679857&z=17',
    },
  ];

  return (
    <section id="contact" className="section-premium bg-sand-light relative overflow-hidden">
      {/* Decorative blob */}
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl translate-y-1/2 translate-x-1/2" />
      
      <div className="container-premium relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="badge-premium mb-4">Контакты</span>
          <h2 className="font-display font-semibold text-3xl md:text-4xl text-text mb-4">
            Свяжитесь с нами
          </h2>
          <p className="text-text-muted text-lg">
            Получите бесплатную консультацию и расчёт стоимости вашего фасада
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 items-start">
          {/* Contact Info */}
          <div>
            <div className="space-y-4 mb-8">
              {contacts.map((contact, index) => (
                <a
                  key={index}
                  href={contact.href}
                  className="flex items-center gap-4 bg-white rounded-xl p-5 shadow-premium hover:shadow-premium-md transition-all group"
                  target={contact.href.startsWith('http') ? '_blank' : undefined}
                  rel={contact.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                >
                  <div className="w-12 h-12 bg-primary-light rounded-xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                    {contact.icon}
                  </div>
                  <div>
                    <p className="text-text-light text-xs uppercase tracking-wider mb-1">
                      {contact.title}
                    </p>
                    <p className="font-display font-medium text-text">
                      {contact.value}
                    </p>
                  </div>
                </a>
              ))}
            </div>

            {/* Working hours */}
            <div className="bg-white rounded-xl p-6 shadow-premium">
              <h3 className="font-display font-semibold text-text mb-4">Режим работы</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-text-muted">Понедельник — Пятница</span>
                  <span className="font-medium text-text">9:00 — 18:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-muted">Суббота</span>
                  <span className="font-medium text-text">10:00 — 15:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-text-muted">Воскресенье</span>
                  <span className="font-medium text-text-light">Выходной</span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl p-6 md:p-8 shadow-premium-lg">
            <h3 className="font-display font-semibold text-xl text-text mb-6">
              Оставить заявку
            </h3>

            {submitted ? (
              <div className="text-center py-10">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircleIcon size={32} className="text-green-600" />
                </div>
                <h4 className="font-display font-semibold text-xl text-text mb-2">
                  Заявка отправлена!
                </h4>
                <p className="text-text-muted">
                  Мы свяжемся с вами в ближайшее время
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm text-text-muted mb-2">Ваше имя</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Иван Иванов"
                    className="w-full px-4 py-3 bg-sand-light rounded-xl border border-transparent focus:border-primary focus:outline-none transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm text-text-muted mb-2">Телефон *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+7 (___) ___-__-__"
                    className="w-full px-4 py-3 bg-sand-light rounded-xl border border-transparent focus:border-primary focus:outline-none transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm text-text-muted mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="example@mail.ru"
                    className="w-full px-4 py-3 bg-sand-light rounded-xl border border-transparent focus:border-primary focus:outline-none transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-sm text-text-muted mb-2">Сообщение</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Опишите ваш проект или задайте вопрос..."
                    rows={4}
                    className="w-full px-4 py-3 bg-sand-light rounded-xl border border-transparent focus:border-primary focus:outline-none transition-colors resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full btn-premium btn-premium--primary"
                >
                  Отправить заявку
                </button>
                <p className="text-xs text-text-light text-center">
                  Нажимая кнопку, вы соглашаетесь с политикой конфиденциальности
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
