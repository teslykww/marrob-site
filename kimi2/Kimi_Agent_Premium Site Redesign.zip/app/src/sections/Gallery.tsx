import React, { useState } from 'react';
import { XIcon, ChevronRightIcon } from '../components/icons/BuildingIcons';

const Gallery: React.FC = () => {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentImage, setCurrentImage] = useState(0);

  const projects = [
    {
      image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&q=80',
      title: 'Коттедж в Красногорске',
      location: 'Московская область',
      area: '280 м²',
      texture: 'Клинкерный кирпич, Красный',
    },
    {
      image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80',
      title: 'Загородный дом',
      location: 'Новая Рига',
      area: '195 м²',
      texture: 'Версальский кирпич, Кремовый',
    },
    {
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&q=80',
      title: 'Современная вилла',
      location: 'Рублёвка',
      area: '350 м²',
      texture: 'Скандинавский кирпич, Серый',
    },
    {
      image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&q=80',
      title: 'Таунхаус',
      location: 'Одинцово',
      area: '165 м²',
      texture: 'Туринский кирпич, Капучино',
    },
    {
      image: 'https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&q=80',
      title: 'Частный дом',
      location: 'Истра',
      area: '220 м²',
      texture: 'Византийский кирпич, Терракота',
    },
    {
      image: 'https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&q=80',
      title: 'Коттеджный посёлок',
      location: 'Дмитровское шоссе',
      area: '180 м²',
      texture: 'Шумерский кирпич, Песчаник',
    },
  ];

  const openLightbox = (index: number) => {
    setCurrentImage(index);
    setLightboxOpen(true);
    document.body.style.overflow = 'hidden';
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    document.body.style.overflow = '';
  };

  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % projects.length);
  };

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + projects.length) % projects.length);
  };

  return (
    <section id="gallery" className="section-premium bg-sand-light relative overflow-hidden">
      {/* Decorative blob */}
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl translate-y-1/2" />
      
      <div className="container-premium relative z-10">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="badge-premium mb-4">Портфолио</span>
          <h2 className="font-display font-semibold text-3xl md:text-4xl text-text mb-4">
            Дома с фасадами из термопанелей <span className="text-primary">MARROB</span>
          </h2>
          <p className="text-text-muted text-lg">
            Реальные объекты, реализованные с использованием нашей фасадной системы
          </p>
        </div>

        {/* Gallery Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-premium hover:shadow-premium-lg transition-all duration-300"
            >
              {/* Image */}
              <div
                className="relative aspect-[4/3] overflow-hidden cursor-pointer"
                onClick={() => openLightbox(index)}
              >
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                <div className="absolute top-4 right-4 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-text">
                    <circle cx="11" cy="11" r="8"/>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"/>
                    <line x1="11" y1="8" x2="11" y2="14"/>
                    <line x1="8" y1="11" x2="14" y2="11"/>
                  </svg>
                </div>
              </div>

              {/* Info */}
              <div className="p-5">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-display font-semibold text-text">{project.title}</h3>
                  <span className="text-xs px-2 py-1 bg-primary-light text-primary rounded-full">
                    {project.area}
                  </span>
                </div>
                <p className="text-text-light text-sm mb-1">{project.location}</p>
                <p className="text-text-muted text-xs">{project.texture}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="bg-white rounded-2xl p-6 shadow-premium flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-10">
          <div className="text-center">
            <div className="font-display font-bold text-4xl text-primary mb-1">6 500+</div>
            <div className="text-text-light text-sm">домов уже утеплены</div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-border" />
          <div className="text-center">
            <div className="text-text-muted text-sm">и облицованы нашей системой</div>
            <div className="text-text-light text-xs mt-1">по всей России и СНГ</div>
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {lightboxOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center"
          onClick={closeLightbox}
        >
          <button
            className="absolute top-6 right-6 w-12 h-12 bg-white/10 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
            onClick={closeLightbox}
          >
            <XIcon size={24} />
          </button>

          <button
            className="absolute left-6 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              prevImage();
            }}
          >
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>

          <button
            className="absolute right-6 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              nextImage();
            }}
          >
            <ChevronRightIcon size={24} />
          </button>

          <div className="max-w-5xl max-h-[80vh] px-20" onClick={(e) => e.stopPropagation()}>
            <img
              src={projects[currentImage].image}
              alt={projects[currentImage].title}
              className="max-w-full max-h-[70vh] object-contain rounded-lg"
            />
            <div className="text-center mt-4 text-white">
              <h3 className="font-display font-semibold text-lg">{projects[currentImage].title}</h3>
              <p className="text-white/70 text-sm">
                {projects[currentImage].location} • {projects[currentImage].texture}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Gallery;
